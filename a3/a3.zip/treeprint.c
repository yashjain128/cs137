#include <stdio.h>


void tree(int n){
  
}



int main(void){
    tree(8);
}
