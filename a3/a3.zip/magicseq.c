#include <stdio.h>





// DO NOT CHANGE THIS PART
int main(void){
    printf("%d\n", magicSequence());
}