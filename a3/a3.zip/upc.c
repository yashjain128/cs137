#include <stdbool.h>
#include <assert.h>
#include <stdio.h>

int sum_odd_digits(long long int num){
	if (num == 0) {
		return 0;
	}
	return sum_odd_digits(num/100) + num%10; 
}

bool validate_upc(long long int num){
	int check_digit = num%10; 

	int odd_sum = sum_odd_digits(num/10);   // odd digits start at tens place
	int even_sum = sum_odd_digits(num/100); // even digits start at hundreds place
	
	int check_sum = ((odd_sum)*3 + even_sum) % 10;
	return check_sum + check_digit == 10;
}

/*
int main(void) {
	assert(validate_upc(725272730706));
	assert(!validate_upc(725272730704));
	assert(!validate_upc(640754291001));
	assert(validate_upc(640754291004));
	assert(validate_upc(693508003156));
	assert(validate_upc(123456789012)); 
	assert(!validate_upc(123456789013)); 
	return 0;
}
*/