#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void square(int w);
void spiral(int w);
void rotation(int w);

#endif
