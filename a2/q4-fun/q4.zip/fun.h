#ifndef FUN_FUNCTIONS
#define FUN_FUNCTIONS

int isSophieGermainPrime(int p);
int base2nat(int bs, int num);
int nat2base(int bs, int num);

#endif
